Laks or Treat: a Halloween game from the Royal Norwegian Embassy in Washington

What's here
  index.html     the game
  art/           title art, portraits, power-ups and the link-preview image
  favicon.svg    the salmon icon for the browser tab
  _headers       caching and basic security headers for Cloudflare

Putting it online with Cloudflare Drop (no account needed to start)
  1. Go to https://cloudflare.com/drop
  2. Drag in this zip (or the unzipped folder).
  3. You get a live preview link that lasts 1 hour. Test it on a phone.
  4. Click Claim and sign in (or create an account) to keep the site.

After it's live
  Link previews on Facebook, LinkedIn and X need the full address of the preview image.
  In index.html, change   content="art/share.jpg"
  to the full address,     content="https://YOUR-SITE-ADDRESS/art/share.jpg"
  and upload again.

Updating later
  Replace the changed files and upload again. Images are cached for a day,
  so a changed picture can take up to 24 hours to show for returning visitors
  unless you also rename it.
